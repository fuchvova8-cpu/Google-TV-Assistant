# Gemini TV — Android TV assistant

A clean Android project intended for Xiaomi Mi TV 4A running Android 9. It uses the native Android speech-recognition UI and Android TextToSpeech, and calls Gemini through its HTTPS REST API.

## Features in this starter build

- TV launcher entry (`LEANBACK_LAUNCHER`) and ordinary Android launcher entry.
- Large remote-friendly dark interface.
- Russian speech input through `RecognizerIntent`.
- Gemini text generation through `generateContent`.
- Local settings for API key and model name.
- Text-to-speech in the hidden voice-search entry point.
- Separate activity that is not shown in the launcher, callable by an explicit intent.
- GitHub Actions workflow that builds and uploads a debug APK.

## Build on GitHub

1. Create an empty repository named `Google-TV-Assistant` under `fuchvova8-cpu`.
2. Upload the contents of this folder to the repository root (the `.github` folder must be included).
3. Open **Actions** and run **Build Gemini TV APK**, or push a commit to `main`.
4. Download `Gemini-TV-debug-apk` from the completed workflow run's Artifacts section.

## Build locally

Requires JDK 17, Android SDK platform 35 and Gradle 8.7:

```bash
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## First launch

Open **Настройки**, paste your Gemini API key from Google AI Studio, and save. The default model is `gemini-3.8-flash`; if your API key/project does not have access to it, enter another model currently enabled for your project.

Gemini REST requests use `x-goog-api-key` and the `generateContent` endpoint. See the [Gemini API documentation](https://ai.google.dev/gemini-api/docs).

## Voice-search intent

The hidden activity can be launched by another foreground app using:

```bash
adb shell am start -a com.fuchvova8.geminitv.VOICE_SEARCH
```

It is hidden from the launcher, but Android still displays the system speech-recognition interface. The target TV must have a compatible speech-recognition service installed and configured.

## Compatibility notes

- `minSdk 23`; `targetSdk 28` to keep compatibility with Android 9-era TV devices.
- No Google TV / TVQuickActions dependency is required.
- Voice recognition depends on the speech service available on the TV; it is not an offline speech engine.
- This is a starter implementation. The API key is stored in app-private preferences, not in a hardware-backed vault. Do not publish your key in GitHub or source code.
