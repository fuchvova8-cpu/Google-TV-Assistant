package com.fuchvova8.geminitv;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Local conversation memory shared by the main UI and the voice-search activity. */
public final class ConversationStore {
    private static final String PREFS = "gemini_tv";
    private static final String KEY = "conversation_history";
    private static final int MAX_MESSAGES = 20; // 10 user/model exchanges
    private ConversationStore() {}

    public static synchronized JSONArray getMessages(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        try {
            return new JSONArray(prefs.getString(KEY, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    public static synchronized void addExchange(Context context, String question, String answer) {
        JSONArray old = getMessages(context);
        JSONArray updated = new JSONArray();
        try {
            for (int i = 0; i < old.length(); i++) {
                JSONObject item = old.optJSONObject(i);
                if (item != null) updated.put(item);
            }
            updated.put(new JSONObject().put("role", "user").put("text", question));
            updated.put(new JSONObject().put("role", "model").put("text", answer));
            JSONArray trimmed = new JSONArray();
            int start = Math.max(0, updated.length() - MAX_MESSAGES);
            if ((updated.length() - start) % 2 != 0) start++;
            for (int i = start; i < updated.length(); i++) trimmed.put(updated.get(i));
            context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, trimmed.toString()).apply();
        } catch (Exception ignored) {
            // History problems must never prevent a response.
        }
    }

    public static synchronized void clear(Context context) {
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY).apply();
    }
}
