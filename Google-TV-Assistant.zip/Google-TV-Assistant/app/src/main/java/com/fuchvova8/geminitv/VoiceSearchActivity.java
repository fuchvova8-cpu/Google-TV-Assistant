package com.fuchvova8.geminitv;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

/** Hidden-from-launcher entry point. Start with action com.fuchvova8.geminitv.VOICE_SEARCH. */
public class VoiceSearchActivity extends Activity {
    private static final int REQUEST_RECOGNITION = 202;
    private TextView message;
    private TextToSpeech tts;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
            | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        );
        prefs = getSharedPreferences("gemini_tv", MODE_PRIVATE);
        LinearLayout panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER); panel.setPadding(32,24,32,24);
        message = new TextView(this); message.setText("🎙 Слушаю…"); message.setTextSize(22); message.setTextColor(0xffffffff);
        panel.addView(message); setContentView(panel);
        tts = new TextToSpeech(this, result -> { if (result == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("ru", "RU")); });
        startRecognition();
    }
    private void startRecognition() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU"); i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажите запрос");
            startActivityForResult(i, REQUEST_RECOGNITION);
        } catch (Exception e) { message.setText("Распознавание речи недоступно"); }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_RECOGNITION) return;
        if (resultCode != RESULT_OK || data == null) { finish(); return; }
        ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if (results == null || results.isEmpty()) { finish(); return; }
        String query = results.get(0); message.setText("Запрос: " + query + "\n\nGemini думает…");
        GeminiClient.askSmart(this, prefs.getString("api_key", ""),
            prefs.getString("model_mode", "auto"), prefs.getString("model", "gemini-3.8-flash"), query,
            new GeminiClient.Callback() {
                @Override public void onResult(String value) { message.setText(value); if (tts != null) tts.speak(value, TextToSpeech.QUEUE_FLUSH, null, "gemini-answer"); }
                @Override public void onError(String error) { message.setText(error); }
            });
    }
    @Override protected void onDestroy() { if (tts != null) { tts.stop(); tts.shutdown(); } super.onDestroy(); }
}
