package com.fuchvova8.geminitv;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class GeminiClient {
    public interface Callback { void onResult(String text); void onError(String message); }
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private GeminiClient() {}

    public static void askSmart(final String apiKey, final String mode, final String manualModel,
                                final String prompt, final Callback callback) {
        EXECUTOR.execute(() -> {
            try {
                if (apiKey == null || apiKey.trim().isEmpty())
                    throw new Exception("Сначала укажи Gemini API Key в настройках.");

                String selectedMode = mode == null ? "auto" : mode;
                List<String> models;
                if ("manual".equals(selectedMode)) {
                    String m = manualModel == null ? "" : manualModel.trim();
                    if (m.isEmpty()) throw new Exception("Укажи ID модели в настройках или выбери режим Авто.");
                    models = new ArrayList<>(); models.add(stripPrefix(m));
                } else {
                    models = listAvailableModels(apiKey.trim());
                    if (models.isEmpty())
                        throw new Exception("Gemini API не вернул моделей с поддержкой generateContent. Проверь API-ключ и доступ к Gemini API.");
                    models = rankModels(models, selectedMode, prompt);
                }

                StringBuilder failures = new StringBuilder();
                for (int i = 0; i < models.size(); i++) {
                    String model = models.get(i);
                    try {
                        String result = generate(apiKey.trim(), model, prompt);
                        final String chosen = model;
                        MAIN.post(() -> callback.onResult(result + "\n\n— Модель: " + chosen));
                        return;
                    } catch (ApiException e) {
                        failures.append("\n• ").append(model).append(": ").append(e.getMessage());
                        // Try another available model only for model/access/temporary server errors.
                        // Do not endlessly retry quota failures across every model.
                        if (e.code == 429) {
                            if (i + 1 < models.size() && i == 0) continue;
                            throw new Exception("Достигнут лимит запросов Gemini (HTTP 429). Смена модели не гарантирует обход лимита. Подожди сброса квоты или проверь лимиты проекта.\n" + failures);
                        }
                        if (!(e.code == 400 || e.code == 404 || e.code == 500 || e.code == 502 || e.code == 503 || e.code == 504))
                            throw new Exception(e.getMessage());
                    }
                }
                throw new Exception("Не удалось получить ответ ни от одной доступной модели:" + failures);
            } catch (Exception e) {
                final String message = e.getMessage() == null ? "Неизвестная ошибка" : e.getMessage();
                MAIN.post(() -> callback.onError(message));
            }
        });
    }

    private static String stripPrefix(String name) {
        return name != null && name.startsWith("models/") ? name.substring(7) : name;
    }

    private static List<String> listAvailableModels(String key) throws Exception {
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1000");
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("GET"); c.setConnectTimeout(15000); c.setReadTimeout(30000);
            c.setRequestProperty("x-goog-api-key", key);
            int code = c.getResponseCode();
            String body = readBody(c, code);
            JSONObject json = new JSONObject(body);
            if (code < 200 || code >= 300) {
                JSONObject err = json.optJSONObject("error");
                String msg = err == null ? "HTTP " + code : err.optString("message", "HTTP " + code);
                throw new Exception("Не удалось получить список моделей: " + msg);
            }
            JSONArray arr = json.optJSONArray("models");
            List<String> result = new ArrayList<>();
            if (arr != null) for (int i=0; i<arr.length(); i++) {
                JSONObject item = arr.optJSONObject(i);
                if (item == null) continue;
                JSONArray methods = item.optJSONArray("supportedGenerationMethods");
                boolean supports = false;
                if (methods != null) for (int j=0; j<methods.length(); j++)
                    if ("generateContent".equals(methods.optString(j))) supports = true;
                String name = stripPrefix(item.optString("name", ""));
                if (supports && name.startsWith("gemini-") && !name.isEmpty()) result.add(name);
            }
            return result;
        } finally { if (c != null) c.disconnect(); }
    }

    private static List<String> rankModels(List<String> available, String mode, String prompt) {
        String q = prompt == null ? "" : prompt.toLowerCase(Locale.ROOT);
        boolean complex = q.length() > 700 || containsAny(q,
            "проанализ", "сравни подробно", "напиши код", "программ", "ошибк", "архитектур",
            "документ", "проект", "почему", "пошагово", "рассчитай", "исследуй",
            "analyze", "compare", "write code", "debug", "architecture", "research");
        List<String> result = new ArrayList<>(available);
        Collections.sort(result, (a,b) -> {
            int ra = score(a, mode, complex), rb = score(b, mode, complex);
            return Integer.compare(ra, rb);
        });
        return result;
    }

    private static boolean containsAny(String text, String... terms) {
        for (String t : terms) if (text.contains(t)) return true;
        return false;
    }

    private static int score(String model, String mode, boolean complex) {
        String m = model.toLowerCase(Locale.ROOT);
        int score = 100;
        boolean lite = m.contains("lite");
        boolean flash = m.contains("flash");
        boolean pro = m.contains("pro");
        boolean preview = m.contains("preview") || m.contains("experimental");
        if ("fast".equals(mode)) {
            if (lite) score -= 60; else if (flash) score -= 45; else if (pro) score += 30;
        } else if ("smart".equals(mode) || complex) {
            if (pro) score -= 60; else if (flash && !lite) score -= 35; else if (lite) score += 25;
        } else {
            if (complex && pro) score -= 45;
            else if (!complex && lite) score -= 40;
            else if (!complex && flash) score -= 30;
            else if (pro) score += 10;
        }
        if (preview) score += 8;
        return score;
    }

    private static String generate(String key, String model, String prompt) throws Exception {
        JSONObject part = new JSONObject().put("text", prompt);
        JSONObject content = new JSONObject().put("role", "user").put("parts", new JSONArray().put(part));
        JSONObject body = new JSONObject().put("contents", new JSONArray().put(content));
        body.put("generationConfig", new JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048));
        byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
        HttpURLConnection c = null;
        try {
            URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
            c = (HttpURLConnection) url.openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(20000); c.setReadTimeout(60000);
            c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("x-goog-api-key", key);
            try (OutputStream out = c.getOutputStream()) { out.write(payload); }
            int code = c.getResponseCode();
            String response = readBody(c, code);
            JSONObject json = new JSONObject(response);
            if (code < 200 || code >= 300) {
                JSONObject error = json.optJSONObject("error");
                String message = error == null ? "Ошибка API HTTP " + code : error.optString("message", "Ошибка API HTTP " + code);
                throw new ApiException(code, message);
            }
            JSONArray candidates = json.optJSONArray("candidates");
            if (candidates == null || candidates.length() == 0)
                throw new ApiException(200, "Модель не вернула текстовый ответ.");
            JSONObject responseContent = candidates.getJSONObject(0).optJSONObject("content");
            JSONArray parts = responseContent == null ? null : responseContent.optJSONArray("parts");
            StringBuilder answer = new StringBuilder();
            if (parts != null) for (int i=0; i<parts.length(); i++)
                answer.append(parts.getJSONObject(i).optString("text", ""));
            if (answer.length() == 0) throw new ApiException(200, "Модель вернула пустой ответ.");
            return answer.toString().trim();
        } finally { if (c != null) c.disconnect(); }
    }

    private static String readBody(HttpURLConnection c, int code) throws Exception {
        InputStream stream = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        StringBuilder b = new StringBuilder();
        if (stream != null) try (BufferedReader r = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line; while ((line = r.readLine()) != null) b.append(line);
        }
        return b.toString();
    }

    private static class ApiException extends Exception {
        final int code;
        ApiException(int code, String message) { super(message); this.code = code; }
    }
}
