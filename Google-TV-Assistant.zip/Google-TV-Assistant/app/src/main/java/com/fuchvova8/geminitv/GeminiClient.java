package com.fuchvova8.geminitv;

import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class GeminiClient {
    public interface Callback { void onResult(String text); void onError(String message); }
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private GeminiClient() {}

    public static void ask(final String apiKey, final String model, final String prompt, final Callback callback) {
        EXECUTOR.execute(() -> {
            try {
                if (apiKey == null || apiKey.trim().isEmpty())
                    throw new Exception("Сначала укажи Gemini API Key в настройках.");

                String safeModel = (model == null || model.trim().isEmpty())
                    ? "gemini-3.8-flash" : model.trim();
                String endpoint = "https://generativelanguage.googleapis.com/v1beta/models/"
                    + safeModel + ":generateContent";

                JSONObject part = new JSONObject().put("text", prompt);
                JSONArray parts = new JSONArray().put(part);
                JSONObject content = new JSONObject().put("role", "user").put("parts", parts);
                JSONObject body = new JSONObject().put("contents", new JSONArray().put(content));
                body.put("generationConfig", new JSONObject()
                    .put("temperature", 0.7).put("maxOutputTokens", 2048));
                byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);

                String lastError = "Не удалось связаться с Gemini.";
                for (int attempt = 0; attempt < 4; attempt++) {
                    HttpURLConnection connection = null;
                    try {
                        URL url = new URL(endpoint);
                        connection = (HttpURLConnection) url.openConnection();
                        connection.setRequestMethod("POST");
                        connection.setConnectTimeout(20000);
                        connection.setReadTimeout(60000);
                        connection.setDoOutput(true);
                        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                        connection.setRequestProperty("x-goog-api-key", apiKey.trim());
                        try (OutputStream out = connection.getOutputStream()) { out.write(payload); }

                        int code = connection.getResponseCode();
                        InputStream stream = (code >= 200 && code < 300)
                            ? connection.getInputStream() : connection.getErrorStream();
                        StringBuilder response = new StringBuilder();
                        if (stream != null) {
                            try (BufferedReader reader = new BufferedReader(
                                    new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                                String line;
                                while ((line = reader.readLine()) != null) response.append(line);
                            }
                        }
                        JSONObject json = new JSONObject(response.toString());

                        if (code >= 200 && code < 300) {
                            JSONArray candidates = json.optJSONArray("candidates");
                            if (candidates == null || candidates.length() == 0)
                                throw new Exception("Gemini не вернул ответ. Попробуй изменить запрос.");
                            JSONObject candidate = candidates.getJSONObject(0);
                            JSONObject responseContent = candidate.optJSONObject("content");
                            JSONArray responseParts = responseContent == null
                                ? null : responseContent.optJSONArray("parts");
                            StringBuilder answer = new StringBuilder();
                            if (responseParts != null) {
                                for (int i = 0; i < responseParts.length(); i++)
                                    answer.append(responseParts.getJSONObject(i).optString("text", ""));
                            }
                            if (answer.length() == 0)
                                throw new Exception("Gemini вернул пустой ответ.");
                            final String result = answer.toString().trim();
                            MAIN.post(() -> callback.onResult(result));
                            return;
                        }

                        JSONObject error = json.optJSONObject("error");
                        lastError = error != null
                            ? error.optString("message", "Ошибка API: HTTP " + code)
                            : "Ошибка API: HTTP " + code;

                        // Retry only temporary overload, quota throttling, and server errors.
                        boolean temporary = code == 429 || code == 500 || code == 502
                            || code == 503 || code == 504;
                        if (!temporary || attempt == 3) {
                            if (code == 503 || code == 429) {
                                lastError = "Gemini сейчас перегружен или ограничил частоту запросов. "
                                    + "Приложение повторило запрос несколько раз. Подожди немного и попробуй снова.\n\n"
                                    + lastError;
                            }
                            throw new Exception(lastError);
                        }
                    } finally {
                        if (connection != null) connection.disconnect();
                    }

                    try { Thread.sleep(1200L * (attempt + 1)); }
                    catch (InterruptedException interrupted) {
                        Thread.currentThread().interrupt();
                        throw new Exception("Запрос прерван.");
                    }
                }
                throw new Exception(lastError);
            } catch (Exception e) {
                final String message = e.getMessage() == null
                    ? "Неизвестная ошибка" : e.getMessage();
                MAIN.post(() -> callback.onError(message));
            }
        });
    }
}
