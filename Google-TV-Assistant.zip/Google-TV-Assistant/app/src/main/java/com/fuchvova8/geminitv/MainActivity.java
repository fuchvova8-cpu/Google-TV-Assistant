package com.fuchvova8.geminitv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 101;
    private SharedPreferences prefs;
    private EditText prompt;
    private TextView answer, status;
    private Button askButton, micButton;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable shape(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }
    private void focusStyle(View v, int normal, int focused) {
        v.setBackground(shape(normal, 22, 0));
        v.setOnFocusChangeListener((view, hasFocus) -> {
            view.setBackground(shape(hasFocus ? focused : normal, 22,
                hasFocus ? Color.rgb(115,174,255) : 0));
            view.setScaleX(hasFocus ? 1.025f : 1f);
            view.setScaleY(hasFocus ? 1.025f : 1f);
        });
    }
    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label); b.setTextSize(17); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setPadding(dp(18),dp(8),dp(18),dp(8));
        b.setMinHeight(dp(54)); b.setFocusable(true);
        focusStyle(b, Color.rgb(34,43,65), Color.rgb(55,75,112));
        return b;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private void gap(LinearLayout row, int width) {
        View v = new View(this); row.addView(v,new LinearLayout.LayoutParams(dp(width),1));
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        );
        getWindow().setStatusBarColor(Color.rgb(5,10,22));
        getWindow().setNavigationBarColor(Color.rgb(5,10,22));
        prefs = getSharedPreferences("gemini_tv", MODE_PRIVATE);
        buildUi();
        if (getIntent() != null && getIntent().hasExtra("query")) {
            String q = getIntent().getStringExtra("query"); prompt.setText(q); ask(q);
        }
    }

    private void buildUi() {
        FrameLayout frame = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setImageResource(com.fuchvova8.geminitv.R.drawable.background_mountain);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(bg, new FrameLayout.LayoutParams(-1,-1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0xB8000716,0x78000A1C,0xD9000817}));
        frame.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(54),dp(24),dp(54),dp(30));
        scroll.addView(root);
        frame.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        setContentView(frame);

        // TV navigation strip
        LinearLayout nav = row();
        TextView brand = text("✦  GEMINI TV",22,Color.WHITE);
        brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        nav.addView(brand,new LinearLayout.LayoutParams(dp(220),dp(58)));
        TextView home = text("Главная",17,Color.WHITE);
        home.setGravity(Gravity.CENTER); home.setPadding(dp(22),0,dp(22),0);
        home.setBackground(shape(0x553C5A89,28,0));
        nav.addView(home,new LinearLayout.LayoutParams(-2,dp(48)));
        TextView history = text("История",17,0xFFD3D9EA);
        history.setPadding(dp(28),0,dp(20),0); nav.addView(history);
        View spacer = new View(this); nav.addView(spacer,new LinearLayout.LayoutParams(0,1,1));
        Button settings = button("⚙  Настройки"); settings.setTextSize(15);
        nav.addView(settings,new LinearLayout.LayoutParams(-2,dp(48)));
        root.addView(nav);

        // Hero area
        TextView title = text("Gemini",54,Color.WHITE);
        title.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0,dp(26),0,0);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(86)));
        TextView subtitle = text("Ваш умный помощник на Android TV",21,0xFFD4D9E8);
        subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0,0,0,dp(22));
        root.addView(subtitle);

        // Search field and controls
        LinearLayout search = row();
        search.setPadding(dp(18),dp(8),dp(12),dp(8));
        search.setBackground(shape(0xE51B263D,34,0xFF6689C6));
        prompt = new EditText(this);
        prompt.setSingleLine(true); prompt.setTextSize(21);
        prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(0xFFABB5CC);
        prompt.setHint("Спросите что-нибудь у Gemini...");
        prompt.setBackgroundColor(Color.TRANSPARENT);
        prompt.setPadding(dp(12),dp(8),dp(12),dp(8));
        prompt.setSelectAllOnFocus(false);
        search.addView(prompt,new LinearLayout.LayoutParams(0,dp(58),1));
        micButton = button("🎙");
        micButton.setTextSize(20);
        search.addView(micButton,new LinearLayout.LayoutParams(dp(66),dp(54)));
        gap(search,10);
        askButton = button("➜");
        askButton.setTextSize(22);
        search.addView(askButton,new LinearLayout.LayoutParams(dp(66),dp(54)));
        root.addView(search,new LinearLayout.LayoutParams(-1,dp(78)));

        TextView hint = text("ПОПУЛЯРНЫЕ ЗАПРОСЫ",14,0xFFB7C7E5);
        hint.setTypeface(null,Typeface.BOLD); hint.setPadding(dp(4),dp(22),0,dp(10));
        root.addView(hint);
        LinearLayout suggestions = row();
        String[] samples = {"Погода на завтра","Найди фильм","Включи музыку","Новости","Расскажи интересное"};
        for (String sample : samples) {
            Button b = button(sample);
            b.setTextSize(15);
            b.setOnClickListener(v -> { prompt.setText(sample); ask(sample); });
            suggestions.addView(b,new LinearLayout.LayoutParams(-2,dp(52)));
            gap(suggestions,10);
        }
        root.addView(suggestions);

        TextView answerLabel = text("ОТВЕТ GEMINI",14,0xFFB7C7E5);
        answerLabel.setTypeface(null,Typeface.BOLD); answerLabel.setPadding(dp(4),dp(24),0,dp(9));
        root.addView(answerLabel);
        LinearLayout response = new LinearLayout(this);
        response.setOrientation(LinearLayout.VERTICAL);
        response.setPadding(dp(22),dp(16),dp(22),dp(18));
        response.setBackground(shape(0xD91A2438,22,0x554D6A9C));
        status = text("Готов к работе",15,0xFF8AB4F8);
        answer = text("Спросите Gemini о чём угодно — ответ появится здесь.",19,Color.WHITE);
        answer.setGravity(Gravity.TOP);
        answer.setPadding(0,dp(8),0,0);
        response.addView(status); response.addView(answer);
        root.addView(response,new LinearLayout.LayoutParams(-1,-2));

        micButton.setOnClickListener(v -> startVoice());
        askButton.setOnClickListener(v -> ask(prompt.getText().toString().trim()));
        settings.setOnClickListener(v -> settingsDialog());
        prompt.setOnEditorActionListener((v, actionId, event) -> {
            ask(prompt.getText().toString().trim()); return true;
        });
        prompt.setOnFocusChangeListener((v, focused) -> {
            if (focused) search.setBackground(shape(0xF022304B,34,0xFF8AB4F8));
            else search.setBackground(shape(0xE51B263D,34,0xFF6689C6));
        });
    }

    private void startVoice() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ru-RU");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Скажите запрос для Gemini");
            startActivityForResult(i,SPEECH_REQUEST);
        } catch (Exception e) { status.setText("Голосовой ввод недоступен на этом устройстве"); }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==SPEECH_REQUEST && resultCode==RESULT_OK && data!=null) {
            ArrayList<String> results=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results!=null && !results.isEmpty()) { prompt.setText(results.get(0)); ask(results.get(0)); }
        }
    }
    private void ask(String question) {
        if (question==null || question.trim().isEmpty()) {
            status.setText("Введите вопрос или нажмите микрофон"); return;
        }
        prompt.setText(question); askButton.setEnabled(false); status.setText("Gemini думает…");
        answer.setText("Подождите, получаю ответ…");
        GeminiClient.askSmart(prefs.getString("api_key",""),
            prefs.getString("model_mode","auto"),
            prefs.getString("model","gemini-3.8-flash"),question,new GeminiClient.Callback() {
            @Override public void onResult(String value) {
                answer.setText(value); status.setText("Ответ готов"); askButton.setEnabled(true);
            }
            @Override public void onError(String message) {
                answer.setText(message); status.setText("Не удалось получить ответ"); askButton.setEnabled(true);
            }
        });
    }
    private void settingsDialog() {
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24),dp(8),dp(24),0);
        EditText key=new EditText(this); key.setSingleLine(true); key.setHint("Gemini API Key");
        key.setText(prefs.getString("api_key","")); box.addView(key);
        TextView modeLabel=text("Режим выбора модели",15,0xFFB7C7E5);
        modeLabel.setPadding(0,dp(14),0,dp(4)); box.addView(modeLabel);
        Spinner mode=new Spinner(this);
        String[] modes={"Авто — выбирать автоматически","Быстро — самая быстрая доступная","Умно — приоритет мощным моделям","Вручную — использовать указанную модель"};
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,modes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mode.setAdapter(adapter);
        String savedMode=prefs.getString("model_mode","auto");
        mode.setSelection(savedMode.equals("fast")?1:savedMode.equals("smart")?2:savedMode.equals("manual")?3:0);
        box.addView(mode);
        EditText model=new EditText(this); model.setSingleLine(true); model.setHint("ID модели для ручного режима");
        model.setText(prefs.getString("model","gemini-3.8-flash"));
        box.addView(model);
        TextView note=text("В авто-режиме приложение сначала получает список моделей, доступных именно твоему API-ключу. Для простых запросов выбирает Flash-Lite/Flash, для сложных — Pro/Flash. При недоступности модели пробует другую из списка.",13,0xFFB7C7E5);
        note.setPadding(0,dp(10),0,0); box.addView(note);
        new AlertDialog.Builder(this).setTitle("Настройки Gemini")
            .setMessage("Ключ хранится локально на телевизоре.")
            .setView(box).setNegativeButton("Отмена",null)
            .setPositiveButton("Сохранить",(d,w)->{
                String[] ids={"auto","fast","smart","manual"};
                prefs.edit().putString("api_key",key.getText().toString().trim())
                    .putString("model_mode",ids[mode.getSelectedItemPosition()])
                    .putString("model",model.getText().toString().trim()).apply();
                status.setText("Настройки сохранены");
            }).show();
    }
}
