package com.fuchvova8.geminitv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SPEECH_REQUEST = 101;
    private SharedPreferences prefs;
    private EditText prompt;
    private TextView answer, status;
    private Button askButton;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        prefs = getSharedPreferences("gemini_tv", MODE_PRIVATE);
        buildUi();
        if (getIntent() != null && getIntent().hasExtra("query")) {
            String q = getIntent().getStringExtra("query"); prompt.setText(q); ask(q);
        }
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(18); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackground(shape(Color.rgb(45,55,75), 22));
        b.setFocusable(true); b.setPadding(22, 10, 22, 10); return b;
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(42, 28, 42, 28); root.setBackgroundColor(Color.rgb(16,19,26));
        scroll.addView(root); setContentView(scroll);
        TextView brand = text("✦  Gemini TV", 34, Color.WHITE); brand.setTypeface(null, Typeface.BOLD); root.addView(brand);
        TextView subtitle = text("Голосовой помощник для Android TV", 17, Color.LTGRAY); subtitle.setPadding(2,4,0,22); root.addView(subtitle);
        prompt = new EditText(this); prompt.setSingleLine(false); prompt.setMinLines(1); prompt.setMaxLines(3);
        prompt.setTextSize(20); prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(Color.GRAY);
        prompt.setHint("Спроси что-нибудь у Gemini…"); prompt.setPadding(18,12,18,12);
        prompt.setBackground(shape(Color.rgb(34,40,53), 18)); root.addView(prompt, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout actions = new LinearLayout(this); actions.setGravity(Gravity.CENTER_VERTICAL); actions.setPadding(0,16,0,18);
        Button mic = button("🎙 Микрофон"); askButton = button("Отправить"); Button settings = button("Настройки");
        actions.addView(mic); addGap(actions, 12); actions.addView(askButton); addGap(actions, 12); actions.addView(settings); root.addView(actions);
        status = text("Готов к работе", 16, Color.rgb(138,180,248)); status.setPadding(0,4,0,12); root.addView(status);
        TextView label = text("ОТВЕТ GEMINI", 14, Color.rgb(138,180,248)); label.setTypeface(null, Typeface.BOLD); root.addView(label);
        answer = text("Здесь появятся ответы помощника.", 20, Color.WHITE); answer.setPadding(18,16,18,16);
        answer.setBackground(shape(Color.rgb(27,33,45), 18)); root.addView(answer, new LinearLayout.LayoutParams(-1, -2));
        mic.setOnClickListener(v -> startVoice()); askButton.setOnClickListener(v -> ask(prompt.getText().toString().trim()));
        settings.setOnClickListener(v -> settingsDialog());
        prompt.setOnEditorActionListener((v, actionId, event) -> { ask(prompt.getText().toString().trim()); return true; });
        prompt.requestFocus();
    }
    private void addGap(LinearLayout row, int width) { View gap = new View(this); row.addView(gap, new LinearLayout.LayoutParams(width,1)); }
    private void startVoice() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU"); i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажите запрос для Gemini");
            startActivityForResult(i, SPEECH_REQUEST);
        } catch (Exception e) { status.setText("Голосовой ввод недоступен на этом устройстве"); }
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) { prompt.setText(results.get(0)); ask(results.get(0)); }
        }
    }
    private void ask(String question) {
        if (question == null || question.trim().isEmpty()) { status.setText("Введи вопрос или нажми «Микрофон»"); return; }
        prompt.setText(question); askButton.setEnabled(false); status.setText("Gemini думает…"); answer.setText("Подожди, получаю ответ…");
        GeminiClient.ask(prefs.getString("api_key", ""), prefs.getString("model", "gemini-3.8-flash"), question,
            new GeminiClient.Callback() {
                @Override public void onResult(String value) { answer.setText(value); status.setText("Ответ готов"); askButton.setEnabled(true); }
                @Override public void onError(String message) { answer.setText(message); status.setText("Не удалось получить ответ"); askButton.setEnabled(true); }
            });
    }
    private void settingsDialog() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(24,8,24,0);
        EditText key = new EditText(this); key.setSingleLine(true); key.setHint("Gemini API Key"); key.setText(prefs.getString("api_key", "")); box.addView(key);
        EditText model = new EditText(this); model.setSingleLine(true); model.setHint("Модель Gemini"); model.setText(prefs.getString("model", "gemini-3.8-flash")); box.addView(model);
        new AlertDialog.Builder(this).setTitle("Настройки Gemini").setMessage("Ключ хранится локально на телевизоре.").setView(box)
            .setNegativeButton("Отмена", null).setPositiveButton("Сохранить", (d,w) -> prefs.edit().putString("api_key", key.getText().toString().trim()).putString("model", model.getText().toString().trim()).apply()).show();
    }
}
